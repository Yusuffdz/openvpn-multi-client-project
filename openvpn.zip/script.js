const lastUpdated = document.getElementById("last-updated");
const onlineUsers = document.getElementById("online-users");
const onlineDevices = document.getElementById("online-devices");
const deviceTableBody = document.getElementById("device-table-body");

const API_ENDPOINT = "/.netlify/functions/status";

const formatDeviceType = (type) => {
  if (!type) return "-";

  if (typeof type === "string") {
    return type;
  }

  if (typeof type === "object") {
    const os = type.os || "Device";
    const version = type.version ? ` ${type.version}` : "";
    const clientVersion = type.clientVersion
      ? ` / OpenVPN ${type.clientVersion}`
      : "";

    return `${os}${version}${clientVersion}`;
  }

  return "-";
};

const escapeHtml = (value) => {
  return String(value ?? "-")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
};

const renderDevices = (devices) => {
  if (!devices || devices.length === 0) {
    deviceTableBody.innerHTML = `
      <tr>
        <td colspan="4">Cihaz verisi bulunamadı.</td>
      </tr>
    `;
    return;
  }

  deviceTableBody.innerHTML = devices
    .map((device) => {
      const isOnline = device.status === "Online";
      const badgeClass = isOnline ? "online" : "offline";

      return `
        <tr>
          <td>${escapeHtml(device.name)}</td>
          <td>${escapeHtml(formatDeviceType(device.type))}</td>
          <td>
            <span class="badge ${badgeClass}">
              ${escapeHtml(device.status)}
            </span>
          </td>
          <td>
            <strong>Tünel IP:</strong> ${escapeHtml(device.tunnelIp)}<br>
            <strong>Kullanıcı:</strong> ${escapeHtml(device.user)}<br>
            <strong>Bağlandığı bölge:</strong> ${escapeHtml(device.connectedTo)}
          </td>
        </tr>
      `;
    })
    .join("");
};

const renderError = (message) => {
  onlineUsers.textContent = "Hata";
  onlineDevices.textContent = "Hata";

  deviceTableBody.innerHTML = `
    <tr>
      <td colspan="4">
        <div class="error-box">
          Canlı bağlantı verisi alınamadı: ${escapeHtml(message)}
        </div>
      </td>
    </tr>
  `;

  lastUpdated.textContent = "Canlı veri alınamadı.";
};

const loadStatus = async () => {
  try {
    const response = await fetch(API_ENDPOINT);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "API isteği başarısız oldu.");
    }

    onlineUsers.textContent = `${data.summary.onlineUsers || 0}`;
    onlineDevices.textContent = `${data.summary.onlineDevices || 0} / ${
      data.summary.totalDevices || 0
    }`;

    renderDevices(data.devices);

    const updatedDate = new Date(data.updatedAt);

    lastUpdated.textContent = `Son canlı güncelleme: ${updatedDate.toLocaleDateString(
      "tr-TR"
    )} ${updatedDate.toLocaleTimeString("tr-TR")}`;
  } catch (error) {
    renderError(error.message);
  }
};

loadStatus();

setInterval(loadStatus, 30000);